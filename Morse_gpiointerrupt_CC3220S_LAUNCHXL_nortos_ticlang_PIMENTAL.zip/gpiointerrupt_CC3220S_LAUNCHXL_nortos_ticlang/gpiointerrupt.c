/* Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/Timer.h>

/* Driver configuration */
#include "ti_drivers_config.h"

// LED States
#define LED_DOT     1
#define LED_DASH   2
#define LED_OFF     0

// Messages
#define SOS_MESSAGE 1
#define OK_MESSAGE  2

// Morse Code Messages
const int sosMessage[] = {
    LED_DOT, LED_OFF,           //  Begin the S
    LED_DOT, LED_OFF,
    LED_DOT, LED_OFF, LED_OFF,
    LED_DASH, LED_DASH, LED_DASH, LED_OFF,  // After pause cycle, begin the O
    LED_DASH, LED_DASH, LED_DASH, LED_OFF,
    LED_DASH, LED_DASH, LED_DASH, LED_OFF, LED_OFF,
    LED_DOT, LED_OFF,           // After another pause, begin the next S
    LED_DOT, LED_OFF,
    LED_DOT, LED_OFF, LED_OFF, LED_OFF, LED_OFF  // Additional pause for word break
};

const int okMessage[] = {
    LED_DASH, LED_DASH, LED_DASH, LED_OFF,  // Begin the O
    LED_DASH, LED_DASH, LED_DASH, LED_OFF,
    LED_DASH, LED_DASH, LED_DASH, LED_OFF, LED_OFF,
    LED_DASH, LED_DASH, LED_DASH, LED_OFF,  // Begin the K
    LED_DOT, LED_OFF,
    LED_DASH, LED_DASH, LED_DASH, LED_OFF, LED_OFF, LED_OFF  // Additional pause for word break
};

// Choosing volatile ints to prep for interrupts
volatile int currentMessage = SOS_MESSAGE; // Set our default message
volatile int buttonMessage = SOS_MESSAGE;
volatile int messageIndex = 0;
volatile int isMessageComplete = 1;

// LED Controller based on state and LED GPIO
void setLEDState(int state) {
    if (state == LED_DOT) {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    } else if (state == LED_DASH) {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
    } else {
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
    }
}

/*
 *  ======== timerCallback ========
 *  Callback function for the timer interrupt.
 */
void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
    isMessageComplete = 0;

    const int *message = (currentMessage == SOS_MESSAGE) ? sosMessage : okMessage;
    int messageLength = (currentMessage == SOS_MESSAGE) ? (sizeof(sosMessage) / sizeof(int)) : (sizeof(okMessage) / sizeof(int));

    setLEDState(message[messageIndex]);
    messageIndex++;

    if (messageIndex >= messageLength) {
        messageIndex = 0;
        isMessageComplete = 1;
        currentMessage = buttonMessage; // Switch to the button-selected message
    }
}

// GPIO Callback to change message upon next iteration
void gpioButtonCallback(uint_least8_t index) {
    if (buttonMessage == SOS_MESSAGE ){
        buttonMessage = OK_MESSAGE;
    } else {
        buttonMessage = SOS_MESSAGE;
    }
}

void initTimer(void) {
    Timer_Handle timer0;
    Timer_Params params;

    Timer_init();
    Timer_Params_init(&params);
    params.period = 500000; // 500ms
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
        while (1) {} // Timer initialization failed
    }

    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
        while (1) {} // Timer start failed
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{

}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{

}

/*
 *  ======== mainThread ========
 *  Main entry point for the program.
 */
void *mainThread(void *arg0) {
    GPIO_init();
    initTimer();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonCallback);
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    // Set our defaults
    currentMessage = SOS_MESSAGE;
    buttonMessage = SOS_MESSAGE;

    return NULL;
}
